package com.sist.search;

public class Music_SearchVO {

	   private String music_title;
	   private String music_artist;
	   private String artist_poster;
	public String getMusic_title() {
		return music_title;
	}
	public void setMusic_title(String music_title) {
		this.music_title = music_title;
	}
	public String getMusic_artist() {
		return music_artist;
	}
	public void setMusic_artist(String music_artist) {
		this.music_artist = music_artist;
	}
	public String getArtist_poster() {
		return artist_poster;
	}
	public void setArtist_poster(String artist_poster) {
		this.artist_poster = artist_poster;
	}
	   
}
