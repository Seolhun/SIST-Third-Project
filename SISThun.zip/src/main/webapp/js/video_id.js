var api = 'https://www.googleapis.com/youtube/v3/search';
var key = 'AIzaSyD_qBykuQzEf6-H3AwpDBQQFE1HZVtI8ec';
//function codeChange() {
//		var ajax = new XMLHttpRequest();
//		var string;
//		ajax.open('GET', api + '?part=snippet,id&q=' + songlist[songNo] + '&type=video&key=' + key);
////		alert(songlist[songNo]);
//		ajax.onload = function () {
//		    var json = JSON.parse(this.responseText);
//		    string=json.items[0].snippet.thumbnails.high.url;
//		    datacode[songNo]=string.substr(23,11);
////		    alert(datacode[songNo]);
//		};
//	    ajax.send();
//};